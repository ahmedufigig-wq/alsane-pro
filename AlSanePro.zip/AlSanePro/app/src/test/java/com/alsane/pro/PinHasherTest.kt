package com.alsane.pro

import com.alsane.pro.security.PinHasher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PinHasherTest {
    @Test
    fun sameInputsGiveSameHash() {
        val salt = PinHasher.newSalt()
        assertEquals(PinHasher.hash("1234", salt), PinHasher.hash("1234", salt))
    }

    @Test
    fun differentSaltGivesDifferentHash() {
        assertNotEquals(
            PinHasher.hash("1234", PinHasher.newSalt()),
            PinHasher.hash("1234", PinHasher.newSalt())
        )
    }

    @Test
    fun verifyAcceptsCorrectAndRejectsWrongPin() {
        val salt = PinHasher.newSalt()
        val hash = PinHasher.hash("4321", salt)
        assertTrue(PinHasher.verify("4321", salt, hash))
        assertFalse(PinHasher.verify("4322", salt, hash))
    }

    @Test
    fun hashDoesNotContainPin() {
        val salt = PinHasher.newSalt()
        assertFalse(PinHasher.hash("123456", salt).contains("123456"))
        assertEquals(64, PinHasher.hash("123456", salt).length)
    }

    @Test
    fun pinValidation() {
        assertTrue(PinHasher.isValidPin("1234"))
        assertTrue(PinHasher.isValidPin("12345678"))
        assertFalse(PinHasher.isValidPin("123"))
        assertFalse(PinHasher.isValidPin("123456789"))
        assertFalse(PinHasher.isValidPin("12a4"))
        assertFalse(PinHasher.isValidPin(""))
    }
}
