package com.alsane.pro

import com.alsane.pro.security.Role
import com.alsane.pro.security.Section
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RoleTest {
    @Test
    fun managerCanAccessEverything() {
        Section.entries.forEach { assertTrue(Role.MANAGER.canAccess(it)) }
    }

    @Test
    fun onlyManagerManagesUsersBackupAndStoreSettings() {
        listOf(Role.ACCOUNTANT, Role.SELLER, Role.VIEWER).forEach { r ->
            assertFalse(r.canAccess(Section.USERS))
            assertFalse(r.canAccess(Section.BACKUP))
            assertFalse(r.canAccess(Section.STORE_SETTINGS))
        }
    }

    @Test
    fun viewerCannotSellOrPurchase() {
        assertFalse(Role.VIEWER.canAccess(Section.SALES))
        assertFalse(Role.VIEWER.canAccess(Section.PURCHASES))
        assertTrue(Role.VIEWER.canAccess(Section.REPORTS))
    }

    @Test
    fun sellerCanSellButNotSeeReportsOrCashbox() {
        assertTrue(Role.SELLER.canAccess(Section.SALES))
        assertFalse(Role.SELLER.canAccess(Section.REPORTS))
        assertFalse(Role.SELLER.canAccess(Section.CASHBOX))
    }

    @Test
    fun accountantCanAccessFinancialSections() {
        assertTrue(Role.ACCOUNTANT.canAccess(Section.REPORTS))
        assertTrue(Role.ACCOUNTANT.canAccess(Section.CASHBOX))
        assertTrue(Role.ACCOUNTANT.canAccess(Section.EXPENSES))
    }
}
