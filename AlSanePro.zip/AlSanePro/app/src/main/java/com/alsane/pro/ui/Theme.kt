package com.alsane.pro.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

val Navy = Color(0xFF0B1F3A)
val NavyLight = Color(0xFF16345C)
val Gold = Color(0xFFD4AF37)
val Green = Color(0xFF1F9D6B)

private val LightColors = lightColorScheme(
    primary = Navy,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE6F7),
    onPrimaryContainer = Navy,
    secondary = Gold,
    onSecondary = Navy,
    tertiary = Green,
    background = Color(0xFFF5F6FA),
    onBackground = Color(0xFF111827),
    surface = Color.White,
    onSurface = Color(0xFF111827),
    surfaceVariant = Color(0xFFE8ECF3),
    onSurfaceVariant = Color(0xFF4B5563)
)

private val DarkColors = darkColorScheme(
    primary = Gold,
    onPrimary = Navy,
    primaryContainer = Color(0xFF1B2F4D),
    onPrimaryContainer = Color(0xFFF3E3A5),
    secondary = Gold,
    onSecondary = Navy,
    tertiary = Green,
    background = Color(0xFF081426),
    onBackground = Color(0xFFE8ECF3),
    surface = Color(0xFF0F2038),
    onSurface = Color(0xFFE8ECF3),
    surfaceVariant = Color(0xFF1B2F4D),
    onSurfaceVariant = Color(0xFFB8C2D3)
)

@Composable
fun AlSaneTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            content()
        }
    }
}
