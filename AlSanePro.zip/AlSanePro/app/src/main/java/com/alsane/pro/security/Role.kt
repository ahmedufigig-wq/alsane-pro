package com.alsane.pro.security

enum class Section {
    DASHBOARD, PRODUCTS, SALES, PURCHASES, CUSTOMERS, EXPENSES,
    REPORTS, CASHBOX, USERS, SETTINGS, STORE_SETTINGS, BACKUP
}

enum class Role(val label: String) {
    MANAGER("مدير"),
    ACCOUNTANT("محاسب"),
    SELLER("بائع"),
    VIEWER("مشاهد");

    fun canAccess(section: Section): Boolean = when (this) {
        MANAGER -> true
        ACCOUNTANT -> section in ACCOUNTANT_SECTIONS
        SELLER -> section in SELLER_SECTIONS
        VIEWER -> section in VIEWER_SECTIONS
    }

    private companion object {
        val ACCOUNTANT_SECTIONS = setOf(
            Section.DASHBOARD, Section.PRODUCTS, Section.SALES, Section.PURCHASES,
            Section.CUSTOMERS, Section.EXPENSES, Section.REPORTS, Section.CASHBOX, Section.SETTINGS
        )
        val SELLER_SECTIONS = setOf(
            Section.DASHBOARD, Section.PRODUCTS, Section.SALES, Section.CUSTOMERS, Section.SETTINGS
        )
        val VIEWER_SECTIONS = setOf(
            Section.DASHBOARD, Section.REPORTS, Section.SETTINGS
        )
    }
}
