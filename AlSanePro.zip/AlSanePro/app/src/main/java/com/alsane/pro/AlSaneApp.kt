package com.alsane.pro

import android.app.Application
import androidx.room.Room
import com.alsane.pro.data.MasterDatabase

class AlSaneApp : Application() {
    /** قاعدة البيانات الرئيسية: قائمة المتاجر فقط. لكل متجر قاعدة بيانات مستقلة. */
    val master: MasterDatabase by lazy {
        Room.databaseBuilder(this, MasterDatabase::class.java, "master.db").build()
    }
}
