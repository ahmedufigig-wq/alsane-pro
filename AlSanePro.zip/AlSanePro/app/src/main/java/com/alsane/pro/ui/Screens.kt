package com.alsane.pro.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alsane.pro.data.StoreEntity
import com.alsane.pro.security.Role

@Composable
fun SplashScreen() {
    var go by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { go = true }
    val a by animateFloatAsState(if (go) 1f else 0f, tween(900), label = "splash")
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Navy, NavyLight))),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.alpha(a)) {
            LogoBadge(128.dp)
            Spacer(Modifier.height(20.dp))
            Text("AL-SANE PRO", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(4.dp))
            Text("السّناي برو", color = Color.White, fontSize = 18.sp)
            Spacer(Modifier.height(4.dp))
            Text("إدارة تجارية ومحاسبية", color = Color(0xFFB8C2D3), fontSize = 13.sp)
        }
    }
}

@Composable
private fun AuthLayout(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(12.dp))
        LogoBadge(88.dp)
        Spacer(Modifier.height(8.dp))
        Text("AL-SANE PRO", color = Gold, fontWeight = FontWeight.Bold, fontSize = 22.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(12.dp))
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(20.dp))
        content()
    }
}

@Composable
fun StoreListScreen(vm: AppViewModel) {
    AuthLayout("اختر المتجر", "اختر المتجر الذي تريد الدخول إليه") {
        vm.stores.forEach { s ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { vm.selectStore(s) }
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Store, contentDescription = null, tint = Gold)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(s.name, fontWeight = FontWeight.Bold)
                        if (s.phone.isNotBlank()) {
                            Text(s.phone, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = { vm.openCreateStore() }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Filled.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("إضافة متجر جديد")
        }
    }
}

@Composable
fun CreateStoreScreen(vm: AppViewModel) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var owner by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }

    AuthLayout("إنشاء متجر جديد", "أدخل بيانات المتجر وحساب المدير") {
        AppField(name, { name = it }, "اسم المتجر")
        AppField(phone, { phone = it }, "رقم الهاتف", keyboardType = KeyboardType.Phone)
        AppField(address, { address = it }, "العنوان")
        Spacer(Modifier.height(8.dp))
        AppField(owner, { owner = it }, "اسم المدير")
        PinField(pin, { pin = it }, "PIN (من 4 إلى 8 أرقام)")
        PinField(pin2, { pin2 = it }, "تأكيد PIN")
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { vm.createStore(name, phone, address, owner, pin, pin2) },
            enabled = !vm.busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (vm.busy) "جارٍ الإنشاء..." else "إنشاء المتجر") }
        if (vm.stores.isNotEmpty()) {
            TextButton(onClick = { vm.goStoreList() }) { Text("رجوع") }
        }
    }
}

@Composable
fun LoginScreen(vm: AppViewModel, store: StoreEntity) {
    val active = remember(vm.users) { vm.users.filter { it.active } }
    var selectedId by remember(active) { mutableStateOf(active.singleOrNull()?.id) }
    var pin by remember { mutableStateOf("") }
    val selected = active.firstOrNull { it.id == selectedId }

    AuthLayout(store.name, "اختر المستخدم وأدخل PIN") {
        active.forEach { u ->
            val isSel = u.id == selectedId
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isSel) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { selectedId = u.id }
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = isSel, onClick = { selectedId = u.id })
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text(u.name, fontWeight = FontWeight.Bold)
                        Text(Role.valueOf(u.role).label, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        PinField(pin, { pin = it }, "PIN")
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                selected?.let { vm.login(it, pin) }
                pin = ""
            },
            enabled = selected != null && pin.length >= 4,
            modifier = Modifier.fillMaxWidth()
        ) { Text("دخول") }
        TextButton(onClick = { vm.goStoreList() }) { Text("تغيير المتجر") }
    }
}
