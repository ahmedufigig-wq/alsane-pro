package com.alsane.pro.ui

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.alsane.pro.AlSaneApp
import com.alsane.pro.data.AuditEntity
import com.alsane.pro.data.StoreDatabase
import com.alsane.pro.data.StoreEntity
import com.alsane.pro.data.UserEntity
import com.alsane.pro.security.PinHasher
import com.alsane.pro.security.Role
import com.alsane.pro.security.Section
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface Screen {
    data object Splash : Screen
    data object StoreList : Screen
    data object CreateStore : Screen
    data class Login(val store: StoreEntity) : Screen
    data object Main : Screen
}

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val master = (application as AlSaneApp).master
    private val prefs = application.getSharedPreferences("alsane_prefs", Context.MODE_PRIVATE)
    private var db: StoreDatabase? = null
    private var failedAttempts = 0
    private var lockedUntil = 0L
    private var stoppedAt = 0L

    var screen by mutableStateOf<Screen>(Screen.Splash)
        private set
    var tab by mutableStateOf(MainTab.HOME)
    var stores by mutableStateOf<List<StoreEntity>>(emptyList())
        private set
    var currentStore by mutableStateOf<StoreEntity?>(null)
        private set
    var currentUser by mutableStateOf<UserEntity?>(null)
        private set
    var users by mutableStateOf<List<UserEntity>>(emptyList())
        private set
    var audit by mutableStateOf<List<AuditEntity>>(emptyList())
        private set
    var darkMode by mutableStateOf(prefs.getBoolean("dark", false))
        private set
    var autoLockMinutes by mutableIntStateOf(prefs.getInt("autolock", 2))
        private set
    var message by mutableStateOf<String?>(null)
        private set
    var busy by mutableStateOf(false)
        private set

    init {
        viewModelScope.launch {
            stores = master.storeDao().all()
            delay(1400)
            screen = if (stores.isEmpty()) Screen.CreateStore else Screen.StoreList
        }
    }

    // ---------------- مساعدات ----------------

    fun consumeMessage() { message = null }

    private fun openStoreDb(name: String): StoreDatabase {
        db?.takeIf { it.openHelper.databaseName == name }?.let { return it }
        db?.close()
        return Room.databaseBuilder(getApplication<Application>(), StoreDatabase::class.java, name).build().also { db = it }
    }

    private suspend fun hashPin(pin: String): Pair<String, String> = withContext(Dispatchers.Default) {
        val salt = PinHasher.newSalt()
        salt to PinHasher.hash(pin, salt)
    }

    private suspend fun log(action: String, details: String = "") {
        db?.auditDao()?.insert(
            AuditEntity(
                userName = currentUser?.name ?: "-",
                action = action,
                details = details,
                createdAt = System.currentTimeMillis()
            )
        )
    }

    private suspend fun refreshData() {
        val sdb = db ?: return
        audit = sdb.auditDao().recent(10)
        users = sdb.userDao().all()
    }

    private fun requireManager(): Boolean {
        val me = currentUser
        val ok = me != null && Role.valueOf(me.role).canAccess(Section.USERS)
        if (!ok) message = "لا تملك صلاحية لهذه العملية"
        return ok
    }

    private fun pinError(pin: String, pin2: String? = null): String? = when {
        !PinHasher.isValidPin(pin) -> "PIN يجب أن يتكون من 4 إلى 8 أرقام"
        pin2 != null && pin != pin2 -> "PIN وتأكيده غير متطابقين"
        else -> null
    }

    // ---------------- التنقل ----------------

    fun goStoreList() {
        screen = if (stores.isEmpty()) Screen.CreateStore else Screen.StoreList
    }

    fun openCreateStore() { screen = Screen.CreateStore }

    // ---------------- المتاجر ----------------

    fun createStore(
        name: String, phone: String, address: String,
        owner: String, pin: String, pin2: String
    ) {
        val n = name.trim()
        val o = owner.trim()
        val error = when {
            n.isEmpty() -> "أدخل اسم المتجر"
            o.isEmpty() -> "أدخل اسم المدير"
            else -> pinError(pin, pin2)
        }
        if (error != null) { message = error; return }
        if (busy) return
        busy = true
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val dbName = "store_$now.db"
            try {
                val sdb = openStoreDb(dbName)
                val (salt, hash) = hashPin(pin)
                sdb.userDao().insert(
                    UserEntity(name = o, role = Role.MANAGER.name, pinHash = hash, salt = salt, createdAt = now)
                )
                sdb.auditDao().insert(
                    AuditEntity(userName = o, action = "إنشاء المتجر", details = n, createdAt = now)
                )
                // يُسجَّل المتجر في القاعدة الرئيسية بعد نجاح تجهيز قاعدته بالكامل
                master.storeDao().insert(
                    StoreEntity(name = n, phone = phone.trim(), address = address.trim(), dbName = dbName, createdAt = now)
                )
                stores = master.storeDao().all()
                message = "تم إنشاء المتجر بنجاح"
                screen = Screen.StoreList
            } catch (e: Exception) {
                db?.close()
                db = null
                getApplication<Application>().deleteDatabase(dbName)
                message = "تعذر إنشاء المتجر"
            } finally {
                busy = false
            }
        }
    }

    fun selectStore(store: StoreEntity) {
        viewModelScope.launch {
            try {
                val sdb = openStoreDb(store.dbName)
                users = sdb.userDao().all()
                currentStore = store
                screen = Screen.Login(store)
            } catch (e: Exception) {
                message = "تعذر فتح بيانات المتجر"
            }
        }
    }

    fun updateStore(name: String, phone: String, address: String) {
        if (!requireManager()) return
        val store = currentStore ?: return
        if (name.isBlank()) { message = "اسم المتجر مطلوب"; return }
        viewModelScope.launch {
            val updated = store.copy(name = name.trim(), phone = phone.trim(), address = address.trim())
            master.storeDao().update(updated)
            currentStore = updated
            stores = master.storeDao().all()
            log("تعديل بيانات المتجر")
            refreshData()
            message = "تم حفظ بيانات المتجر"
        }
    }

    // ---------------- الدخول والخروج ----------------

    fun login(user: UserEntity, pin: String) {
        val now = System.currentTimeMillis()
        if (now < lockedUntil) {
            message = "محاولات كثيرة. انتظر ${(lockedUntil - now) / 1000 + 1} ثانية"
            return
        }
        viewModelScope.launch {
            val ok = withContext(Dispatchers.Default) { PinHasher.verify(pin, user.salt, user.pinHash) }
            if (ok) {
                failedAttempts = 0
                currentUser = user
                tab = MainTab.HOME
                log("تسجيل دخول")
                refreshData()
                screen = Screen.Main
            } else {
                failedAttempts++
                if (failedAttempts >= 5) {
                    failedAttempts = 0
                    lockedUntil = System.currentTimeMillis() + 30_000
                    message = "5 محاولات خاطئة. تم الإيقاف 30 ثانية"
                } else {
                    message = "PIN غير صحيح"
                }
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            log("تسجيل خروج")
            currentUser = null
            tab = MainTab.HOME
            users = db?.userDao()?.all() ?: emptyList()
            val store = currentStore
            screen = if (store != null) Screen.Login(store) else Screen.StoreList
        }
    }

    fun switchStore() {
        viewModelScope.launch {
            log("تسجيل خروج")
            currentUser = null
            currentStore = null
            tab = MainTab.HOME
            screen = Screen.StoreList
        }
    }

    // ---------------- القفل التلقائي ----------------

    fun onAppStopped() { stoppedAt = System.currentTimeMillis() }

    fun onAppStarted() {
        val away = if (stoppedAt > 0) System.currentTimeMillis() - stoppedAt else 0L
        stoppedAt = 0
        if (screen == Screen.Main && autoLockMinutes > 0 && away >= autoLockMinutes * 60_000L) {
            logout()
        }
    }

    // ---------------- المستخدمون ----------------

    fun addUser(name: String, role: Role, pin: String, onSuccess: () -> Unit) {
        if (!requireManager()) return
        val n = name.trim()
        val error = if (n.isEmpty()) "أدخل اسم المستخدم" else pinError(pin)
        if (error != null) { message = error; return }
        viewModelScope.launch {
            val sdb = db ?: return@launch
            try {
                val (salt, hash) = hashPin(pin)
                sdb.userDao().insert(
                    UserEntity(
                        name = n, role = role.name, pinHash = hash, salt = salt,
                        createdAt = System.currentTimeMillis()
                    )
                )
                log("إضافة مستخدم", "$n (${role.label})")
                refreshData()
                message = "تمت إضافة المستخدم"
                onSuccess()
            } catch (e: Exception) {
                message = "الاسم مستخدم مسبقاً"
            }
        }
    }

    fun setUserActive(target: UserEntity, active: Boolean) {
        if (!requireManager()) return
        val me = currentUser ?: return
        if (target.id == me.id) { message = "لا يمكنك تعطيل حسابك الحالي"; return }
        viewModelScope.launch {
            val sdb = db ?: return@launch
            if (!active && target.role == Role.MANAGER.name && sdb.userDao().activeManagers() <= 1) {
                message = "يجب أن يبقى مدير واحد فعّال على الأقل"
                return@launch
            }
            sdb.userDao().update(target.copy(active = active))
            log(if (active) "تفعيل مستخدم" else "تعطيل مستخدم", target.name)
            refreshData()
        }
    }

    fun resetUserPin(target: UserEntity, newPin: String, onSuccess: () -> Unit) {
        if (!requireManager()) return
        val error = pinError(newPin)
        if (error != null) { message = error; return }
        viewModelScope.launch {
            val sdb = db ?: return@launch
            val (salt, hash) = hashPin(newPin)
            sdb.userDao().update(target.copy(pinHash = hash, salt = salt))
            log("إعادة تعيين PIN", target.name)
            refreshData()
            message = "تم تغيير PIN"
            onSuccess()
        }
    }

    fun changeMyPin(old: String, new: String, new2: String, onSuccess: () -> Unit) {
        val me = currentUser ?: return
        val error = pinError(new, new2)
        if (error != null) { message = error; return }
        viewModelScope.launch {
            val ok = withContext(Dispatchers.Default) { PinHasher.verify(old, me.salt, me.pinHash) }
            if (!ok) { message = "PIN الحالي غير صحيح"; return@launch }
            val (salt, hash) = hashPin(new)
            val updated = me.copy(pinHash = hash, salt = salt)
            db?.userDao()?.update(updated)
            currentUser = updated
            log("تغيير PIN")
            refreshData()
            message = "تم تغيير PIN"
            onSuccess()
        }
    }

    // ---------------- التفضيلات ----------------

    fun setDarkMode(value: Boolean) {
        darkMode = value
        prefs.edit().putBoolean("dark", value).apply()
    }

    fun setAutoLock(minutes: Int) {
        autoLockMinutes = minutes
        prefs.edit().putInt("autolock", minutes).apply()
    }

    override fun onCleared() {
        db?.close()
        super.onCleared()
    }
}

enum class MainTab(val label: String, val section: Section) {
    HOME("الرئيسية", Section.DASHBOARD),
    USERS("المستخدمون", Section.USERS),
    SETTINGS("الإعدادات", Section.SETTINGS)
}
