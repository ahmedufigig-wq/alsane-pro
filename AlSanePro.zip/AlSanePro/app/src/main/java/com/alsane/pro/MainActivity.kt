package com.alsane.pro

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.material3.Surface
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.platform.LocalContext
import com.alsane.pro.ui.AlSaneTheme
import com.alsane.pro.ui.AppViewModel
import com.alsane.pro.ui.CreateStoreScreen
import com.alsane.pro.ui.LoginScreen
import com.alsane.pro.ui.MainScreen
import com.alsane.pro.ui.Screen
import com.alsane.pro.ui.SplashScreen
import com.alsane.pro.ui.StoreListScreen

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        setContent {
            AlSaneTheme(dark = vm.darkMode) {
                AppRoot(vm)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        vm.onAppStarted()
    }

    override fun onStop() {
        super.onStop()
        vm.onAppStopped()
    }
}

@Composable
fun AppRoot(vm: AppViewModel) {
    val context = LocalContext.current
    LaunchedEffect(vm.message) {
        vm.message?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            vm.consumeMessage()
        }
    }
    val screen = vm.screen
    BackHandler(enabled = screen is Screen.Login || (screen == Screen.CreateStore && vm.stores.isNotEmpty())) {
        vm.goStoreList()
    }
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        when (screen) {
            Screen.Splash -> SplashScreen()
            Screen.StoreList -> StoreListScreen(vm)
            Screen.CreateStore -> CreateStoreScreen(vm)
            is Screen.Login -> LoginScreen(vm, screen.store)
            Screen.Main -> MainScreen(vm)
        }
    }
}
