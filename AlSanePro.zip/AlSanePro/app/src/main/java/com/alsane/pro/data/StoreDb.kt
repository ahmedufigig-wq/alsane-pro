package com.alsane.pro.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Update

@Entity(tableName = "users", indices = [Index(value = ["name"], unique = true)])
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val role: String,
    val pinHash: String,
    val salt: String,
    val active: Boolean = true,
    val createdAt: Long
)

@Entity(tableName = "audit_log")
data class AuditEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userName: String,
    val action: String,
    val details: String = "",
    val createdAt: Long
)

@Dao
interface UserDao {
    @Query("SELECT * FROM users ORDER BY id")
    suspend fun all(): List<UserEntity>

    @Query("SELECT COUNT(*) FROM users WHERE role = 'MANAGER' AND active = 1")
    suspend fun activeManagers(): Int

    @Insert
    suspend fun insert(user: UserEntity): Long

    @Update
    suspend fun update(user: UserEntity)
}

@Dao
interface AuditDao {
    @Insert
    suspend fun insert(entry: AuditEntity)

    @Query("SELECT * FROM audit_log ORDER BY id DESC LIMIT :n")
    suspend fun recent(n: Int): List<AuditEntity>
}

/** قاعدة بيانات المتجر: ملف مستقل تماماً لكل متجر (عزل كامل للبيانات). */
@Database(entities = [UserEntity::class, AuditEntity::class], version = 1, exportSchema = false)
abstract class StoreDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun auditDao(): AuditDao
}
