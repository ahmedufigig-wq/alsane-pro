package com.alsane.pro.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alsane.pro.data.UserEntity
import com.alsane.pro.security.Role
import com.alsane.pro.security.Section

private fun MainTab.icon(): ImageVector = when (this) {
    MainTab.HOME -> Icons.Filled.Home
    MainTab.USERS -> Icons.Filled.People
    MainTab.SETTINGS -> Icons.Filled.Settings
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(vm: AppViewModel) {
    val user = vm.currentUser ?: return
    val role = Role.valueOf(user.role)
    val tabs = MainTab.entries.filter { role.canAccess(it.section) }
    val tab = if (vm.tab in tabs) vm.tab else MainTab.HOME

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(vm.currentStore?.name ?: "AL-SANE PRO", fontWeight = FontWeight.Bold) },
                actions = {
                    androidx.compose.material3.IconButton(onClick = { vm.logout() }) {
                        Icon(Icons.Filled.Lock, contentDescription = "قفل التطبيق")
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Navy,
                    titleContentColor = Color.White,
                    actionIconContentColor = Gold
                )
            )
        },
        bottomBar = {
            NavigationBar {
                tabs.forEach { t ->
                    NavigationBarItem(
                        selected = t == tab,
                        onClick = { vm.tab = t },
                        icon = { Icon(t.icon(), contentDescription = null) },
                        label = { Text(t.label) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                MainTab.HOME -> DashboardScreen(vm)
                MainTab.USERS -> UsersScreen(vm)
                MainTab.SETTINGS -> SettingsScreen(vm)
            }
        }
    }
}

// ======================= لوحة التحكم =======================

@Composable
fun DashboardScreen(vm: AppViewModel) {
    val user = vm.currentUser ?: return
    val role = Role.valueOf(user.role)
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Brush.horizontalGradient(listOf(Navy, NavyLight)))
                    .padding(20.dp)
            ) {
                Column {
                    Text("مرحباً، ${user.name}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text(vm.currentStore?.name ?: "", color = Gold, fontSize = 15.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("الصلاحية: ${role.label}", color = Color(0xFFB8C2D3), fontSize = 13.sp)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("المستخدمون الفعّالون", vm.users.count { it.active }.toString(), Icons.Filled.People, Modifier.weight(1f))
                StatCard("إجمالي المستخدمين", vm.users.size.toString(), Icons.Filled.Person, Modifier.weight(1f))
            }
        }
        item {
            SectionCard("حالة الوحدات") {
                listOf(
                    "الحسابات والصلاحيات وPIN" to true,
                    "قاعدة البيانات المحلية (ملف مستقل لكل متجر)" to true,
                    "المنتجات والمخزون" to false,
                    "المبيعات ونقاط البيع" to false,
                    "المشتريات والموردون" to false,
                    "العملاء والديون" to false,
                    "المصروفات والصندوق" to false,
                    "التقارير والتصدير" to false,
                    "النسخ الاحتياطي والاستعادة" to false
                ).forEach { (label, ready) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(label, modifier = Modifier.weight(1f))
                        Text(
                            if (ready) "جاهز" else "قيد التطوير",
                            color = if (ready) Green else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
        item {
            SectionCard("آخر العمليات") {
                if (vm.audit.isEmpty()) {
                    Text("لا توجد عمليات بعد", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    vm.audit.forEach { a ->
                        Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Text(
                                a.action + if (a.details.isNotBlank()) " — ${a.details}" else "",
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "${a.userName} · ${formatTime(a.createdAt)}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Card(modifier = modifier) {
        Column(Modifier.padding(16.dp)) {
            Icon(icon, contentDescription = null, tint = Gold)
            Spacer(Modifier.height(8.dp))
            Text(value, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ======================= المستخدمون =======================

@Composable
fun UsersScreen(vm: AppViewModel) {
    val me = vm.currentUser ?: return
    var showAdd by remember { mutableStateOf(false) }
    var resetTarget by remember { mutableStateOf<UserEntity?>(null) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(vm.users, key = { it.id }) { u ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(u.name + if (u.id == me.id) "  (أنت)" else "", fontWeight = FontWeight.Bold)
                                Text(
                                    Role.valueOf(u.role).label + if (!u.active) " · معطّل" else "",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = u.active,
                                onCheckedChange = { vm.setUserActive(u, it) },
                                enabled = u.id != me.id
                            )
                        }
                        TextButton(onClick = { resetTarget = u }) { Text("تغيير PIN") }
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { showAdd = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
            containerColor = Gold,
            contentColor = Navy
        ) { Icon(Icons.Filled.Add, contentDescription = "إضافة مستخدم") }
    }

    if (showAdd) AddUserDialog(vm) { showAdd = false }
    resetTarget?.let { t -> ResetPinDialog(vm, t) { resetTarget = null } }
}

@Composable
private fun AddUserDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var role by remember { mutableStateOf(Role.SELLER) }
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة مستخدم") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                AppField(name, { name = it }, "اسم المستخدم")
                Text("الصلاحية", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                Role.entries.forEach { r ->
                    Row(
                        Modifier.fillMaxWidth().clickable { role = r },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = role == r, onClick = { role = r })
                        Text(r.label)
                    }
                }
                PinField(pin, { pin = it }, "PIN (من 4 إلى 8 أرقام)")
            }
        },
        confirmButton = {
            TextButton(onClick = { vm.addUser(name, role, pin, onDismiss) }) { Text("إضافة") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun ResetPinDialog(vm: AppViewModel, target: UserEntity, onDismiss: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("PIN جديد لـ ${target.name}") },
        text = { PinField(pin, { pin = it }, "PIN الجديد") },
        confirmButton = {
            TextButton(onClick = { vm.resetUserPin(target, pin, onDismiss) }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

// ======================= الإعدادات =======================

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val user = vm.currentUser ?: return
    val role = Role.valueOf(user.role)
    val store = vm.currentStore

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (role.canAccess(Section.STORE_SETTINGS) && store != null) {
            var name by remember(store) { mutableStateOf(store.name) }
            var phone by remember(store) { mutableStateOf(store.phone) }
            var address by remember(store) { mutableStateOf(store.address) }
            SectionCard("بيانات المتجر") {
                AppField(name, { name = it }, "اسم المتجر")
                AppField(phone, { phone = it }, "رقم الهاتف", keyboardType = KeyboardType.Phone)
                AppField(address, { address = it }, "العنوان")
                Spacer(Modifier.height(8.dp))
                Button(onClick = { vm.updateStore(name, phone, address) }, modifier = Modifier.fillMaxWidth()) {
                    Text("حفظ")
                }
            }
        }

        SectionCard("المظهر") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.DarkMode, contentDescription = null, tint = Gold)
                Spacer(Modifier.width(12.dp))
                Text("الوضع الليلي", modifier = Modifier.weight(1f))
                Switch(checked = vm.darkMode, onCheckedChange = { vm.setDarkMode(it) })
            }
        }

        SectionCard("القفل التلقائي") {
            listOf(1, 2, 5, 15).forEach { m ->
                Row(
                    Modifier.fillMaxWidth().clickable { vm.setAutoLock(m) },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = vm.autoLockMinutes == m, onClick = { vm.setAutoLock(m) })
                    Text("بعد $m ${if (m == 1) "دقيقة" else "دقائق"} من الخروج من التطبيق")
                }
            }
        }

        var old by remember { mutableStateOf("") }
        var new by remember { mutableStateOf("") }
        var new2 by remember { mutableStateOf("") }
        SectionCard("تغيير PIN الخاص بي") {
            PinField(old, { old = it }, "PIN الحالي")
            PinField(new, { new = it }, "PIN الجديد")
            PinField(new2, { new2 = it }, "تأكيد PIN الجديد")
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { vm.changeMyPin(old, new, new2) { old = ""; new = ""; new2 = "" } },
                modifier = Modifier.fillMaxWidth()
            ) { Text("تغيير PIN") }
        }

        SectionCard("الحساب") {
            Button(onClick = { vm.logout() }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Lock, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("قفل التطبيق الآن")
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { vm.switchStore() }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Store, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("تبديل المتجر")
            }
        }

        Text(
            "AL-SANE PRO · الإصدار 0.1.0 (المرحلة 1)",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
