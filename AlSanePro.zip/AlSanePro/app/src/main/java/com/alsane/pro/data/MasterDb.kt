package com.alsane.pro.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Update

@Entity(tableName = "stores")
data class StoreEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val address: String = "",
    val dbName: String,
    val createdAt: Long
)

@Dao
interface StoreDao {
    @Query("SELECT * FROM stores ORDER BY id")
    suspend fun all(): List<StoreEntity>

    @Insert
    suspend fun insert(store: StoreEntity): Long

    @Update
    suspend fun update(store: StoreEntity)
}

@Database(entities = [StoreEntity::class], version = 1, exportSchema = false)
abstract class MasterDatabase : RoomDatabase() {
    abstract fun storeDao(): StoreDao
}
